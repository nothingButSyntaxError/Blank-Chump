# Blank-Chump
## A discord economy system made for marketing purposes!
## Credits - Parth, Samar , Yash.
